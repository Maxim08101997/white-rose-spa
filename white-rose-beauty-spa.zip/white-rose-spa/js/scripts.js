
document.addEventListener('DOMContentLoaded', function () {
  const modal = document.getElementById('modal');
  const openModalBtn = document.createElement('button');
  openModalBtn.textContent = 'Записаться';
  openModalBtn.style.margin = '20px auto';
  openModalBtn.style.display = 'block';
  document.body.insertBefore(openModalBtn, document.querySelector('footer'));
  openModalBtn.addEventListener('click', () => modal.style.display = 'flex');
  document.querySelector('.close').addEventListener('click', () => modal.style.display = 'none');
  window.addEventListener('click', (e) => {
    if (e.target === modal) modal.style.display = 'none';
  });

  ymaps.ready(() => {
    const map = new ymaps.Map("map", {
      center: [56.6388, 47.8908],
      zoom: 15
    });
    map.geoObjects.add(new ymaps.Placemark([56.6388, 47.8908], {
      balloonContent: 'White Rose Beauty SPA'
    }));
  });
});
